put a page with in a form to edit an account
