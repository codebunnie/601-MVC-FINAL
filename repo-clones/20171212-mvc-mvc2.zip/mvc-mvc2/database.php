<?php

define('DATABASE', 'kwilliam');
define('USERNAME', 'kwilliam');
define('PASSWORD', 'USracpEto');
define('CONNECTION', 'sql2.njit.edu');
